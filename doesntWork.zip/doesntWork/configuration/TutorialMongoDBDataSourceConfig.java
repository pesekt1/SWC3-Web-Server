package swc3.server.configuration;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import swc3.server.model.mongoDB.TutorialMongoDB;

import javax.sql.DataSource;

@Configuration
@EnableJpaRepositories(basePackages = "swc3.server.repository.mongoDB",
        entityManagerFactoryRef = "tutorialMongoDBEntityManagerFactory",
        transactionManagerRef= "tutorialMongoDBTransactionManager")
public class TutorialMongoDBDataSourceConfig {

    @Bean
    @ConfigurationProperties("spring.data.mongodb")
    public DataSourceProperties tutorialMongoDBDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean
    @ConfigurationProperties("spring.data.mongodb.configuration")
    public DataSource tutorialMongoDBDataSource() {
        return tutorialMongoDBDataSourceProperties().initializeDataSourceBuilder()
                .type(BasicDataSource.class).build();
    }

    @Bean(name = "tutorialMongoDBEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean tutorialMongoDBEntityManagerFactory(
            EntityManagerFactoryBuilder builder) {
        return builder
                .dataSource(tutorialMongoDBDataSource())
                .packages(TutorialMongoDB.class)
                .build();
    }

    @Bean
    public PlatformTransactionManager tutorialMongoDBTransactionManager(
            final @Qualifier("tutorialMongoDBEntityManagerFactory") LocalContainerEntityManagerFactoryBean tutorialMongoDBEntityManagerFactory) {
        return new JpaTransactionManager(tutorialMongoDBEntityManagerFactory.getObject());
    }

}