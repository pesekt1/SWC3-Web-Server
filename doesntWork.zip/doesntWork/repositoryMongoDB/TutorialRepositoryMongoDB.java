package swc3.server.repository.mongoDB;

import org.springframework.data.mongodb.repository.MongoRepository;
import swc3.server.model.mongoDB.TutorialMongoDB;

import java.util.List;

public interface TutorialRepositoryMongoDB extends MongoRepository<TutorialMongoDB, String> {
  List<TutorialMongoDB> findByPublished(boolean published);
  List<TutorialMongoDB> findByTitleContaining(String title);
}
